Star Type Classification Dataset
================================

Dieses Dataset dient zur Klassifikation von Sternen anhand physikalischer und
spektraler Merkmale. Zielvariable ist `Type`, eine diskrete Klasse von `0` bis
`5`.

## Attribute

| Spalte | Bedeutung |
| --- | --- |
| `Temperature` | Oberflaechentemperatur des Sterns in Kelvin |
| `L` | Relative Leuchtkraft im Vergleich zur Sonne |
| `R` | Relativer Radius im Vergleich zur Sonne |
| `A_M` | Absolute Magnitude, also intrinsische Helligkeit |
| `Color` | Beobachtete Farbe im sichtbaren Spektrum |
| `Spectral_Class` | Spektralklasse nach Harvard-System (`O`, `B`, `A`, `F`, `G`, `K`, `M`) |
| `Type` | Zielvariable fuer die Sternklasse |

## Zielklassen

| Type | Klasse |
| --- | --- |
| 0 | Red Dwarf |
| 1 | Brown Dwarf |
| 2 | White Dwarf |
| 3 | Main Sequence |
| 4 | Super Giants |
| 5 | Hyper Giants |

## Wichtige Beobachtungen zur Datei

Die Datei `nasa_stars_data.csv` ist keine klassische komma-separierte CSV-Datei.
Sie verwendet `~` als Trennzeichen. Zudem steht vor der eigentlichen Kopfzeile
eine Beschreibungszeile, und rechts neben den relevanten sieben Spalten befinden
sich leere Zusatzspalten. Beim Laden muessen daher folgende Punkte beachtet
werden:

- Separator: `~`
- Relevante Spalten: die ersten sieben Spalten
- Die erste Textzeile vor dem Header muss uebersprungen werden
- Leere Zusatzspalten koennen entfernt werden
- Es gibt fehlende Werte in `Temperature`, `R`, `Color` und `Spectral_Class`
- `Color` enthaelt uneinheitliche Schreibweisen wie `Blue White`,
  `Blue-white`, `Blue-wh!te`, `Blu`, `white`, ` White` usw.

## Machine-Learning-Idee

Als ueberwachtes Lernproblem wird `Type` vorhergesagt. Geeignete Features sind:

- Numerisch: `Temperature`, `L`, `R`, `A_M`
- Kategorisch: `Color`, `Spectral_Class`

Die vorgeschlagene Pipeline bereinigt Kategorien, imputiert fehlende Werte,
skaliert numerische Variablen und kodiert kategoriale Variablen per
One-Hot-Encoding. Anschliessend werden mehrere Klassifikationsmodelle
verglichen, z. B. Logistic Regression, Random Forest und Support Vector Machine.

## Abgabehinweis

Die Originaldaten werden nicht manuell ueberschrieben. Die Bereinigung erfolgt
reproduzierbar im Notebook `star_type_classification.ipynb`.
